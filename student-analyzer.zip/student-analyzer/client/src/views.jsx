import React, { useState, useEffect } from 'react';
import { api, download, toast, SUBJECTS, EXAMS, COLORS, mean, grade } from './api.js';
import { Line, Bars, Scatter, Heat, Legend, Kpi } from './charts.jsx';

function useApi(path) {
  const [state, set] = useState({ data: null, error: '' });
  useEffect(() => { let live = true; api(path).then(data => live && set({ data, error: '' })).catch(e => live && set({ data: null, error: e.message })); return () => { live = false; }; }, [path]);
  return state;
}
const Status = ({ error }) => error ? <div className="err">{error}</div> : <p>Loading…</p>;
const Modal = ({ children, close }) => <div className="modal" onClick={close}><div className="card" onClick={e => e.stopPropagation()}>{children}</div></div>;

/* ---------- student progress modal ---------- */
function Detail({ s, all, user, close, onEdit, onChanged }) {
  const [cd, setCd] = useState(0);
  const final = s.marks.map(m => m[3]), avg = mean(final), hist = EXAMS.map((_, e) => mean(s.marks.map(m => m[e])));
  const [g, gc] = grade(avg);
  const best = SUBJECTS[final.indexOf(Math.max(...final))], weak = SUBJECTS[final.indexOf(Math.min(...final))];
  const delta = hist[3] - hist[0];
  const rank = [...all].map(x => ({ id: x.id, a: mean(x.marks.map(m => m[3])) })).sort((a, b) => b.a - a.a).findIndex(x => x.id === s.id) + 1;
  const del = async () => {
    if (!cd) return setCd(1);
    try { await api(`/api/students/${s.id}`, { method: 'DELETE' }); toast(`${s.name} was removed`); onChanged(); close(); } catch (e) { setCd(e.message); }
  };
  return <Modal close={close}>
    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}>
      <div><h2>{s.name}</h2><p className="sub-t">Roll {s.roll} · Section {s.section} · Attendance {s.attendance}%</p></div>
      <div className="row-actions" style={{ alignItems: 'flex-start' }}>
        <button className="btn" onClick={onEdit}>Edit</button>
        {user.role === 'admin' && <button className="btn danger" onClick={del}>{cd === 1 ? 'Confirm delete?' : 'Delete'}</button>}
        <button className="btn sec" onClick={close}>Close</button>
      </div>
    </div>
    {typeof cd === 'string' && <div className="err">{cd}</div>}
    <div className="grid g4" style={{ marginBottom: 14 }}>
      <Kpi v={avg.toFixed(1)} l="Final average" /><Kpi v={<span style={{ color: gc }}>{g}</span>} l="Grade" />
      <Kpi v={(delta >= 0 ? '+' : '') + delta.toFixed(1)} l="Change since Unit 1" /><Kpi v={`#${rank}`} l="Overall rank" />
    </div>
    <div className="grid g2">
      <div className="card"><h3>Progress by exam (overall)</h3><Line labels={EXAMS} series={[{ name: 'Overall', color: '#0284c7', values: hist, w: 3 }]} /></div>
      <div className="card"><h3>Latest score by subject</h3><Bars items={SUBJECTS.map((x, i) => ({ label: x, value: final[i], color: COLORS[i] }))} /></div>
      <div className="card" style={{ gridColumn: '1/-1' }}><h3>Subject-wise trend</h3>
        <Line labels={EXAMS} series={SUBJECTS.map((x, i) => ({ name: x, color: COLORS[i], values: s.marks[i] }))} />
        <Legend items={SUBJECTS.map((x, i) => ({ name: x, color: COLORS[i] }))} /></div>
    </div>
    <p style={{ marginBottom: 0 }}><b>Insight:</b> Strongest in <b>{best}</b>, needs support in <b>{weak}</b>. {delta >= 0 ? 'Performance is improving.' : 'Performance is declining — consider a check-in.'}</p>
  </Modal>;
}

/* ---------- add / edit form ---------- */
function StudentForm({ init, close, onChanged }) {
  const edit = !!init.id;
  const [f, setF] = useState({ name: init.name || '', roll: init.roll || '', section: init.section || 'A', attendance: init.attendance ?? 85 });
  const [m, setM] = useState(init.marks || SUBJECTS.map(() => EXAMS.map(() => 70)));
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const setMark = (i, e, v) => setM(m.map((r, a) => a === i ? r.map((x, b) => b === e ? v : x) : r));
  const up = k => e => setF({ ...f, [k]: e.target.value });
  const save = async () => {
    setBusy(true); setErr('');
    try {
      await api(edit ? `/api/students/${init.id}` : '/api/students', { method: edit ? 'PUT' : 'POST', body: { ...f, marks: m } });
      toast(edit ? 'Changes saved' : `${f.name} was added`); onChanged(); close();
    } catch (e) { setErr(e.message); setBusy(false); }
  };
  return <Modal close={close}>
    <h2>{edit ? 'Edit student' : 'Add student'}</h2>
    {err && <div className="err">{err}</div>}
    <div className="grid g4">
      <div><small>Name</small><input className="inp" value={f.name} onChange={up('name')} /></div>
      <div><small>Roll no.</small><input className="inp" type="number" value={f.roll} onChange={up('roll')} /></div>
      <div><small>Section</small><input className="inp" maxLength={3} value={f.section} onChange={up('section')} /></div>
      <div><small>Attendance %</small><input className="inp" type="number" value={f.attendance} onChange={up('attendance')} /></div>
    </div>
    <div className="scroll"><table><thead><tr><th>Subject</th>{EXAMS.map(x => <th key={x}>{x}</th>)}</tr></thead>
      <tbody>{SUBJECTS.map((s, i) => <tr key={s}><td><b>{s}</b></td>{EXAMS.map((x, e) => <td key={x}><input className="inp" style={{ width: 80, margin: 0 }} type="number" min="0" max="100" value={m[i][e]} onChange={ev => setMark(i, e, ev.target.value)} /></td>)}</tr>)}</tbody></table></div>
    <div className="row-actions" style={{ marginTop: 14 }}><button className="btn" disabled={busy} onClick={save}>{busy ? 'Saving…' : 'Save student'}</button><button className="btn sec" onClick={close}>Cancel</button></div>
  </Modal>;
}

/* ---------- students table ---------- */
export function Students({ sec, all, user, onChanged, initialId }) {
  const [q, setQ] = useState(''); const [sel, setSel] = useState(() => all.find(x => x.id === initialId) || null); const [form, setForm] = useState(null);
  const list = all.filter(s => s.section === sec && s.name.toLowerCase().includes(q.toLowerCase()));
  return <>
    <div className="row-actions" style={{ justifyContent: 'space-between', alignItems: 'flex-start' }}>
      <div><h2>Section {sec} — Student details</h2><p className="sub-t">Click any student row to see their progress visualisation.</p></div>
      <button className="btn" onClick={() => setForm('new')}>+ Add student</button>
    </div>
    <div className="card"><input className="inp" placeholder="Search student name…" value={q} onChange={e => setQ(e.target.value)} />
      <div className="scroll"><table><thead><tr><th>Roll</th><th>Student name</th>{SUBJECTS.map(s => <th key={s}>{s}</th>)}<th>Avg</th><th>Grade</th><th>Attend.</th></tr></thead>
        <tbody>{list.map(s => { const f = s.marks.map(m => m[3]), a = mean(f), [g, c] = grade(a); return <tr key={s.id} className="row" onClick={() => setSel(s)}>
          <td>{s.roll}</td><td><b>{s.name}</b></td>{f.map((m, i) => <td key={i}>{m}</td>)}<td><b>{a.toFixed(1)}</b></td>
          <td><span className="pill" style={{ background: c }}>{g}</span></td><td style={{ minWidth: 100 }}><div className="bar"><i style={{ width: s.attendance + '%' }} /></div></td></tr>; })}
          {!list.length && <tr><td colSpan={10}>No students match here yet. Use “Add student” to create one.</td></tr>}</tbody></table></div></div>
    {sel && <Detail s={sel} all={all} user={user} close={() => setSel(null)} onChanged={onChanged} onEdit={() => { setForm(sel); setSel(null); }} />}
    {form && <StudentForm init={form === 'new' ? { section: sec } : form} close={() => setForm(null)} onChanged={onChanged} />}
  </>;
}

/* ---------- dashboard / analytics / EDA (data comes from SQL on the server) ---------- */
const secList = o => Object.keys(o).sort();
export function Dashboard({ user, openStudent }) {
  const { data: d, error } = useApi('/api/analytics');
  if (!d) return <Status error={error} />;
  const secs = secList(d.sectionTrend);
  const h = new Date().getHours(), hello = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  const bestSec = [...d.sections].sort((a, b) => b.avg - a.avg)[0], bestSub = [...d.subjects].sort((a, b) => b.avg - a.avg)[0], weakSub = [...d.subjects].sort((a, b) => a.avg - b.avg)[0];
  return <><p className="hello"><b>{hello}, {user.name.split(' ')[0]}.</b></p>
    <p className="sub-t">{d.kpis.atRisk ? `${d.kpis.atRisk} student${d.kpis.atRisk > 1 ? 's' : ''} could use extra support. ` : 'Everyone is on track. '}
      Section {bestSec.section} is doing best (average {bestSec.avg.toFixed(1)}), {bestSub.subject} is the strongest subject and {weakSub.subject} needs the most attention.</p>
    <div className="grid g4" style={{ marginBottom: 14 }}><Kpi v={d.kpis.total} l="Students" /><Kpi v={d.kpis.avg.toFixed(1)} l="School average" /><Kpi v={Math.round(d.kpis.attendance) + '%'} l="Average attendance" /><Kpi v={d.kpis.atRisk} l="Need support (avg < 55)" /></div>
    <div className="grid g2">
      <div className="card"><h3>How each section is trending</h3><Line labels={EXAMS} series={secs.map((x, i) => ({ name: 'Sec ' + x, color: COLORS[i % 5], values: d.sectionTrend[x] }))} /><Legend items={secs.map((x, i) => ({ name: 'Section ' + x, color: COLORS[i % 5] }))} /></div>
      <div className="card"><h3>Students who may need a conversation</h3>
        {!d.attention.length && <p>Nobody is flagged right now. 🎉</p>}
        {d.attention.map(s => <div key={s.id} className="attn" onClick={() => openStudent(s)}><b>{s.name}</b> <small style={{ display: 'inline' }}>· Section {s.section}</small><small>{s.reasons.join(' · ')}</small></div>)}</div>
      <div className="card"><h3>Most improved since Unit 1</h3>{d.improved.map(s => <div key={s.id} className="attn" onClick={() => openStudent(s)}><b>{s.name}</b> <small style={{ display: 'inline' }}>· Section {s.section}</small> <span className="up" style={{ float: 'right' }}>+{s.delta.toFixed(1)}</span></div>)}</div>
      <div className="card"><h3>Top performers</h3>{d.top.map((s, i) => <div key={s.id} className="attn" onClick={() => openStudent(s)} style={{ display: 'flex', justifyContent: 'space-between' }}><span>{i + 1}. {s.name} <small style={{ display: 'inline' }}>(Sec {s.section})</small></span><b>{s.avg.toFixed(1)}</b></div>)}</div>
    </div></>;
}

export function Analytics() {
  const { data: d, error } = useApi('/api/analytics');
  if (!d) return <Status error={error} />;
  const gr = ['D', 'C', 'B', 'A'].map(g => ({ label: 'Grade ' + g, value: d.grades[g], color: grade(g === 'A' ? 90 : g === 'B' ? 75 : g === 'C' ? 60 : 30)[1] }));
  return <><h2>Analytics</h2><p className="sub-t">Performance comparisons across sections and subjects</p>
    <div className="grid g2">
      <div className="card"><h3>Average by section</h3><Bars items={d.sections.map((s, i) => ({ label: 'Sec ' + s.section, value: s.avg, color: COLORS[i % 5] }))} /></div>
      <div className="card"><h3>Average by subject</h3><Bars items={d.subjects.map((s, i) => ({ label: s.subject, value: s.avg, color: COLORS[i] }))} /></div>
      <div className="card"><h3>Grade distribution (students)</h3><Bars items={gr} max={Math.max(...gr.map(b => b.value), 1) + 2} /></div>
      <div className="card"><h3>Subject trend (all students)</h3><Line labels={EXAMS} series={SUBJECTS.map((x, i) => ({ name: x, color: COLORS[i], values: d.subjectTrend[x] || [0, 0, 0, 0] }))} /><Legend items={SUBJECTS.map((x, i) => ({ name: x, color: COLORS[i] }))} /></div>
    </div></>;
}

export function StudentModal({ id, all, user, close, onChanged }) {
  const s = all.find(x => x.id === id); const [edit, setEdit] = useState(false);
  if (!s) return null;
  return edit ? <StudentForm init={s} close={close} onChanged={onChanged} /> : <Detail s={s} all={all} user={user} close={close} onChanged={onChanged} onEdit={() => setEdit(true)} />;
}

export function EDA() {
  const { data: d, error } = useApi('/api/eda');
  if (!d) return <Status error={error} />;
  if (!d.ready) return <p>Add at least 3 students to see exploratory analysis.</p>;
  const r = d.attendanceCorr;
  return <><h2>Exploratory Data Analysis</h2><p className="sub-t">Distributions, summary statistics and correlations</p>
    <div className="card scroll" style={{ marginBottom: 14 }}><h3>Summary statistics</h3><table><thead><tr><th>Variable</th><th>Mean</th><th>Median</th><th>Std dev</th><th>Min</th><th>Max</th></tr></thead>
      <tbody>{d.summary.map(c => <tr key={c.name}><td><b>{c.name}</b></td><td>{c.mean.toFixed(1)}</td><td>{c.median.toFixed(1)}</td><td>{c.std.toFixed(1)}</td><td>{c.min}</td><td>{c.max}</td></tr>)}</tbody></table></div>
    <div className="grid g2">
      <div className="card"><h3>Histogram — average score</h3><Bars items={d.histogram.map(h => ({ ...h, color: '#0284c7' }))} max={Math.max(...d.histogram.map(h => h.value)) + 1} /></div>
      <div className="card"><h3>Attendance vs average (r = {r.toFixed(2)})</h3><Scatter pts={d.scatter} /><p style={{ margin: '6px 0 0', color: 'var(--muted)', fontSize: 13 }}>{Math.abs(r) > .5 ? 'Strong' : 'Moderate'} {r > 0 ? 'positive' : 'negative'} relationship between attendance and score.</p></div>
      <div className="card"><h3>Correlation heatmap</h3><Heat {...d.correlation} /></div>
      <div className="card"><h3>Spread (min / median / max)</h3>{d.summary.slice(0, 5).map((c, i) => <div key={c.name} style={{ margin: '10px 0' }}><small>{c.name}</small><div style={{ position: 'relative', height: 14, background: 'var(--soft)', borderRadius: 7 }}><div style={{ position: 'absolute', left: c.min + '%', width: (c.max - c.min) + '%', height: '100%', background: COLORS[i], opacity: .55, borderRadius: 7 }} /><div style={{ position: 'absolute', left: c.median + '%', width: 3, height: '100%', background: 'var(--text)' }} /></div></div>)}</div>
    </div></>;
}

/* ---------- CSV import / export ---------- */
export function DataPage({ user, onChanged }) {
  const [files, setFiles] = useState({}); const [replace, setReplace] = useState(false); const [msg, setMsg] = useState(null); const [busy, setBusy] = useState(false);
  const run = async () => {
    setMsg(null);
    if (!files.students || !files.marks) return setMsg({ err: 'Choose both students.csv and marks.csv.' });
    setBusy(true);
    try {
      const body = { students: await files.students.text(), marks: await files.marks.text(), replace };
      const r = await api('/api/import', { method: 'POST', body });
      setMsg({ ok: `Imported ${r.imported} students.` }); toast(`Imported ${r.imported} students`); onChanged();
    } catch (e) { setMsg({ err: e.message }); }
    setBusy(false);
  };
  return <><h2>Data (CSV)</h2><p className="sub-t">The SQL database can be loaded from and exported to CSV files.</p>
    <div className="grid g2">
      <div className="card"><h3>Export</h3><p>Download the current database as CSV.</p>
        <div className="row-actions"><button className="btn" onClick={() => download('students')}>students.csv</button><button className="btn" onClick={() => download('marks')}>marks.csv</button></div></div>
      <div className="card"><h3>Import</h3>
        {user.role !== 'admin' ? <p>Only admins can import CSV files.</p> : <>
          <p><code>students.csv</code>: roll, name, section, attendance<br /><code>marks.csv</code>: roll, subject, exam, score<br /><small>Subjects: {SUBJECTS.join(', ')} · Exams: {EXAMS.join(', ')}. Every student needs all {SUBJECTS.length * EXAMS.length} marks.</small></p>
          <small>students.csv</small><input className="inp" type="file" accept=".csv" onChange={e => setFiles({ ...files, students: e.target.files[0] })} />
          <small>marks.csv</small><input className="inp" type="file" accept=".csv" onChange={e => setFiles({ ...files, marks: e.target.files[0] })} />
          <label style={{ display: 'block', marginBottom: 12 }}><input type="checkbox" checked={replace} onChange={e => setReplace(e.target.checked)} /> Replace all existing data</label>
          <button className="btn" disabled={busy} onClick={run}>{busy ? 'Importing…' : 'Import'}</button>
          {msg?.err && <div className="err" style={{ marginTop: 12 }}>{msg.err}</div>}{msg?.ok && <div className="ok">{msg.ok}</div>}</>}
      </div>
    </div></>;
}

import React from 'react';

export function Line({ labels, series, h = 190 }) {
  const W = 420, p = 28, n = labels.length;
  const x = i => p + i * (W - p - 10) / (n - 1), y = v => h - 22 - (v / 100) * (h - 34);
  return <svg viewBox={`0 0 ${W} ${h}`} width="100%">
    {[0, 25, 50, 75, 100].map(t => <g key={t}><line x1={p} x2={W - 10} y1={y(t)} y2={y(t)} stroke="var(--line)" /><text x={4} y={y(t) + 3}>{t}</text></g>)}
    {labels.map((l, i) => <text key={l} x={x(i)} y={h - 6} textAnchor="middle">{l}</text>)}
    {series.map(s => <g key={s.name}><polyline fill="none" stroke={s.color} strokeWidth={s.w || 2} points={s.values.map((v, i) => `${x(i)},${y(v)}`).join(' ')} />
      {s.values.map((v, i) => <circle key={i} cx={x(i)} cy={y(v)} r={3} fill={s.color}><title>{s.name}: {Math.round(v)}</title></circle>)}</g>)}
  </svg>;
}

export function Bars({ items, max = 100, h = 190 }) {
  const W = 420, p = 28, bw = (W - p - 10) / items.length;
  return <svg viewBox={`0 0 ${W} ${h}`} width="100%">
    {[0, 25, 50, 75, 100].map(t => { const yy = h - 22 - (t / 100) * (h - 34); return <g key={t}><line x1={p} x2={W - 10} y1={yy} y2={yy} stroke="var(--line)" /><text x={4} y={yy + 3}>{Math.round(t * max / 100)}</text></g>; })}
    {items.map((d, i) => { const bh = (d.value / max) * (h - 34); return <g key={d.label}>
      <rect x={p + i * bw + bw * .18} y={h - 22 - bh} width={bw * .64} height={bh} rx={4} fill={d.color || 'var(--accent)'}><title>{d.label}: {d.value.toFixed(1)}</title></rect>
      <text x={p + i * bw + bw / 2} y={h - 8} textAnchor="middle">{d.label}</text>
      <text x={p + i * bw + bw / 2} y={h - 26 - bh} textAnchor="middle" style={{ fill: 'var(--text)' }}>{Math.round(d.value)}</text></g>; })}
  </svg>;
}

export function Scatter({ pts, h = 210 }) {
  const W = 420, p = 32, x = v => p + ((v - 50) / 50) * (W - p - 12), y = v => h - 26 - ((v - 30) / 70) * (h - 38);
  return <svg viewBox={`0 0 ${W} ${h}`} width="100%">
    <line x1={p} x2={W - 10} y1={h - 26} y2={h - 26} stroke="var(--line)" /><line x1={p} x2={p} y1={8} y2={h - 26} stroke="var(--line)" />
    <text x={W / 2} y={h - 6} textAnchor="middle">Attendance %</text><text x={4} y={14}>Avg</text>
    {pts.map((q, i) => <circle key={i} cx={x(q.att)} cy={y(q.avg)} r={5} fill="var(--accent)" fillOpacity=".7"><title>{q.name}: {q.att}% / {q.avg.toFixed(0)}</title></circle>)}
  </svg>;
}

export function Heat({ labels, matrix }) {
  const c = 34, o = 64, n = labels.length;
  return <svg viewBox={`0 0 ${o + n * c + 6} ${o + n * c + 6}`} width="100%" style={{ maxWidth: 380 }}>
    {labels.map((a, i) => <g key={a}>
      <text x={o - 4} y={o + i * c + c / 2 + 3} textAnchor="end">{a.slice(0, 8)}</text>
      <text x={o + i * c + c / 2} y={o - 6} textAnchor="middle">{a.slice(0, 4)}</text>
      {labels.map((b, j) => { const r = matrix[i][j]; return <g key={b}>
        <rect x={o + j * c} y={o + i * c} width={c - 2} height={c - 2} rx={4} fill={r >= 0 ? `rgba(2,132,199,${Math.abs(r)})` : `rgba(220,38,38,${Math.abs(r)})`} />
        <text x={o + j * c + c / 2 - 1} y={o + i * c + c / 2 + 3} textAnchor="middle" style={{ fill: Math.abs(r) > .5 ? '#fff' : 'var(--text)' }}>{r.toFixed(2)}</text></g>; })}
    </g>)}
  </svg>;
}

export const Legend = ({ items }) => <div className="legend">{items.map(i => <span key={i.name}><i style={{ background: i.color }} />{i.name}</span>)}</div>;
export const Kpi = ({ v, l }) => <div className="card kpi"><b>{v}</b><span>{l}</span></div>;

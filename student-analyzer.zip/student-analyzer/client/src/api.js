// Small fetch wrapper: adds the JWT, throws readable errors, logs out on 401.
export const SUBJECTS = ['Math', 'Science', 'English', 'History', 'Computer']; // must match server/config.js
export const EXAMS = ['Unit 1', 'Midterm', 'Unit 2', 'Final'];
export const COLORS = ['#0284c7', '#16a34a', '#d97706', '#9333ea', '#dc2626'];

export const getToken = () => localStorage.getItem('spa_token');
export const setToken = t => (t ? localStorage.setItem('spa_token', t) : localStorage.removeItem('spa_token'));

export async function api(path, { method = 'GET', body, raw } = {}) {
  let res;
  try {
    res = await fetch(path, {
      method,
      headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(getToken() ? { Authorization: 'Bearer ' + getToken() } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch { throw new Error('Cannot reach the server. Is the backend running?'); }
  if (raw && res.ok) return res;
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && getToken()) { setToken(null); window.dispatchEvent(new Event('spa-logout')); }
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

export async function download(type) {
  const res = await api(`/api/export/${type}`, { raw: true });
  const url = URL.createObjectURL(await res.blob());
  const a = Object.assign(document.createElement('a'), { href: url, download: `${type}.csv` });
  a.click(); URL.revokeObjectURL(url);
}

export const mean = a => a.reduce((x, y) => x + y, 0) / a.length;
export const grade = v => (v >= 85 ? ['A', '#16a34a'] : v >= 70 ? ['B', '#0284c7'] : v >= 55 ? ['C', '#d97706'] : ['D', '#dc2626']);

// Small toast helper: any component can call toast('Saved'); App renders it.
export const toast = (msg, type = 'ok') => window.dispatchEvent(new CustomEvent('spa-toast', { detail: { msg, type } }));

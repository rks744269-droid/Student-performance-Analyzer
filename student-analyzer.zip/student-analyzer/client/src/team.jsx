import React, { useState, useEffect } from 'react';
import { api, toast } from './api.js';

export function Team({ me }) {
  const [users, setUsers] = useState(null); const [err, setErr] = useState('');
  const [f, setF] = useState({ name: '', email: '', password: '', role: 'teacher' });
  const load = () => api('/api/users').then(setUsers).catch(e => setErr(e.message));
  useEffect(() => { load(); }, []);
  const up = k => e => setF({ ...f, [k]: e.target.value });
  const add = async () => {
    setErr('');
    try { await api('/api/users', { method: 'POST', body: f }); toast(`${f.name} can now log in`); setF({ name: '', email: '', password: '', role: 'teacher' }); load(); }
    catch (e) { setErr(e.message); }
  };
  const role = async (u, r) => { try { await api(`/api/users/${u.id}`, { method: 'PATCH', body: { role: r } }); toast('Role updated'); load(); } catch (e) { toast(e.message, 'bad'); } };
  const del = async u => { if (!confirm(`Remove ${u.name}? They will no longer be able to log in.`)) return; try { await api(`/api/users/${u.id}`, { method: 'DELETE' }); toast(`${u.name} was removed`); load(); } catch (e) { toast(e.message, 'bad'); } };
  return <><h2>Team</h2><p className="sub-t">Teachers can add and edit students. Admins can also delete students, import CSV files and manage this team.</p>
    <div className="grid g2">
      <div className="card scroll"><h3>People with access</h3>
        {!users ? <p>Loading…</p> : <table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th /></tr></thead><tbody>{users.map(u => <tr key={u.id}>
          <td><b>{u.name}</b>{u.id === me.id && ' (you)'}</td><td>{u.email}</td>
          <td><select className="inp" value={u.role} disabled={u.id === me.id} onChange={e => role(u, e.target.value)}><option value="teacher">Teacher</option><option value="admin">Admin</option></select></td>
          <td>{u.id !== me.id && <button className="btn danger" onClick={() => del(u)}>Remove</button>}</td></tr>)}</tbody></table>}</div>
      <div className="card"><h3>Invite a teacher</h3>
        {err && <div className="err">{err}</div>}
        <input className="inp" placeholder="Full name" value={f.name} onChange={up('name')} />
        <input className="inp" type="email" placeholder="Email" value={f.email} onChange={up('email')} />
        <input className="inp" type="text" placeholder="Temporary password (8+ characters)" value={f.password} onChange={up('password')} />
        <select className="inp" style={{ marginBottom: 12 }} value={f.role} onChange={up('role')}><option value="teacher">Teacher</option><option value="admin">Admin</option></select>
        <br /><button className="btn" onClick={add}>Create account</button></div>
    </div></>;
}

export function Account({ me, onChanged }) {
  const [f, setF] = useState({ current: '', next: '', again: '' }); const [err, setErr] = useState('');
  const up = k => e => setF({ ...f, [k]: e.target.value });
  const save = async () => {
    setErr('');
    if (f.next !== f.again) return setErr('The two new passwords do not match.');
    try { await api('/api/auth/password', { method: 'POST', body: { current: f.current, next: f.next } }); toast('Password updated'); setF({ current: '', next: '', again: '' }); onChanged(); }
    catch (e) { setErr(e.message); }
  };
  return <><h2>My account</h2><p className="sub-t">{me.name} · {me.email} · {me.role}</p>
    <div className="card" style={{ maxWidth: 420 }}><h3>Change password</h3>
      {err && <div className="err">{err}</div>}
      <input className="inp" type="password" placeholder="Current password" value={f.current} onChange={up('current')} />
      <input className="inp" type="password" placeholder="New password (8+ characters)" value={f.next} onChange={up('next')} />
      <input className="inp" type="password" placeholder="Repeat new password" value={f.again} onChange={up('again')} onKeyDown={e => e.key === 'Enter' && save()} />
      <button className="btn" onClick={save}>Update password</button></div></>;
}

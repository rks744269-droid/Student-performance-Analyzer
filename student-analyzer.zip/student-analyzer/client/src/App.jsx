import React, { useState, useEffect, useCallback } from 'react';
import { api, getToken, setToken } from './api.js';
import { Students, StudentModal, Dashboard, Analytics, EDA, DataPage } from './views.jsx';
import { Team, Account } from './team.jsx';

function Auth({ onAuth, notice, config }) {
  const [mode, setMode] = useState('login');
  const [f, setF] = useState({ name: '', email: '', password: '' });
  const [err, setErr] = useState(notice || ''); const [busy, setBusy] = useState(false);
  const up = k => e => setF({ ...f, [k]: e.target.value });
  const go = async () => {
    setErr('');
    if (!f.email || !f.password) return setErr('Please enter your email and password.');
    setBusy(true);
    try {
      const r = await api(mode === 'login' ? '/api/auth/login' : '/api/auth/register', { method: 'POST', body: f });
      setToken(r.token); onAuth(r.user);
    } catch (e) { setErr(e.message); setBusy(false); }
  };
  return <div className="login"><div className="card">
    <h2>{config.school}</h2><p className="sub-t">Student Performance Analyzer · sign in to continue</p>
    {config.allowRegister && <div className="auth-tabs"><button className={mode === 'login' ? 'on' : ''} onClick={() => setMode('login')}>Login</button><button className={mode === 'register' ? 'on' : ''} onClick={() => setMode('register')}>Register</button></div>}
    {err && <div className="err">{err}</div>}
    {mode === 'register' && <input className="inp" placeholder="Full name" value={f.name} onChange={up('name')} />}
    <input className="inp" type="email" placeholder="Email" autoComplete="username" value={f.email} onChange={up('email')} />
    <input className="inp" type="password" placeholder="Password" autoComplete="current-password" value={f.password} onChange={up('password')} onKeyDown={e => e.key === 'Enter' && go()} />
    <button className="btn" style={{ width: '100%' }} disabled={busy} onClick={go}>{busy ? 'Please wait…' : mode === 'login' ? 'Login' : 'Create account'}</button>
    {config.devHint && <p style={{ color: 'var(--muted)', fontSize: 12, textAlign: 'center' }}>Local demo: admin@school.com / admin123</p>}
    {!config.allowRegister && <p style={{ color: 'var(--muted)', fontSize: 12, textAlign: 'center' }}>Need an account? Ask your school administrator.</p>}
  </div></div>;
}

class Boundary extends React.Component {
  state = { e: null };
  static getDerivedStateFromError(e) { return { e }; }
  render() {
    if (!this.state.e) return this.props.children;
    return <div className="login"><div className="card"><h2>Something went wrong</h2><div className="err">{String(this.state.e.message || this.state.e)}</div>
      <button className="btn" style={{ width: '100%' }} onClick={() => { setToken(null); location.reload(); }}>Back to Login</button></div></div>;
  }
}

function Shell({ user, config, logout, refreshUser }) {
  const [page, setPage] = useState('dash'); const [sec, setSec] = useState('A'); const [openId, setOpenId] = useState(null);
  const [open, setOpen] = useState(true); const [menu, setMenu] = useState(false);
  const [all, setAll] = useState(null); const [err, setErr] = useState(''); const [v, setV] = useState(0);
  const reload = useCallback(() => setV(x => x + 1), []);
  useEffect(() => { api('/api/students').then(d => { setAll(d); setErr(''); }).catch(e => setErr(e.message)); }, [v]);
  const secs = [...new Set(['A', 'B', 'C', ...(all || []).map(s => s.section)])].sort();
  const nav = p => { setPage(p); setMenu(false); };
  const n = all?.length || 0, isAdmin = user.role === 'admin';
  let body;
  if (err) body = <div className="err">{err}</div>;
  else if (!all) body = <p>Loading…</p>;
  else if (page === 'students') body = <Students key={sec} sec={sec} all={all} user={user} onChanged={reload} />;
  else if (page === 'data') body = <DataPage user={user} onChanged={reload} />;
  else if (page === 'team' && isAdmin) body = <Team me={user} />;
  else if (page === 'account') body = <Account me={user} onChanged={refreshUser} />;
  else if (n < 3) body = <div className="card" style={{ textAlign: 'center', padding: 30 }}><h3>Let’s add your first students</h3><p>Charts and analysis appear once there are at least 3 students. Add them one by one under Students Information, or import your CSV files from Data (CSV).</p></div>;
  else body = page === 'dash' ? <Dashboard key={v} user={user} openStudent={s => setOpenId(s.id)} /> : page === 'analytics' ? <Analytics key={v} /> : <EDA key={v} />;
  const item = (id, label) => <button className={page === id ? 'on' : ''} onClick={() => nav(id)}>{label}</button>;
  return <>
    <div className="nav"><button className="burger" onClick={() => setMenu(!menu)}>☰</button><h1>Student Performance Analyzer<span className="school">{config.school}</span></h1><span className="user">{user.name} · {user.role}</span><button className="btn ghost" onClick={logout}>Logout</button></div>
    <div className="shell"><aside className={'side' + (menu ? ' open' : '')}>
      {item('dash', 'Dashboard')}
      <button className={page === 'students' ? 'on' : ''} onClick={() => { setOpen(page === 'students' ? !open : true); setPage('students'); }}>Students Information <span>{open ? '▾' : '▸'}</span></button>
      {open && <div className="sub">{secs.map(x => <button key={x} className={page === 'students' && sec === x ? 'on' : ''} onClick={() => { setSec(x); nav('students'); }}>Section {x}</button>)}</div>}
      {item('analytics', 'Analytics')}{item('eda', 'EDA')}{item('data', 'Data (CSV)')}
      {isAdmin && item('team', 'Team')}{item('account', 'My account')}
    </aside><main>
      {user.mustChange && page !== 'account' && <div className="banner"><span><b>You’re using a temporary password.</b> Please choose your own to keep student data safe.</span><button className="btn" onClick={() => nav('account')}>Change password</button></div>}
      {body}
      {openId && all && <StudentModal id={openId} all={all} user={user} close={() => setOpenId(null)} onChanged={reload} />}
    </main></div></>;
}

function Toast() {
  const [t, setT] = useState(null);
  useEffect(() => { let id; const on = e => { setT(e.detail); clearTimeout(id); id = setTimeout(() => setT(null), 3200); }; window.addEventListener('spa-toast', on); return () => window.removeEventListener('spa-toast', on); }, []);
  return t ? <div className={'toast' + (t.type === 'bad' ? ' bad' : '')} role="status">{t.msg}</div> : null;
}

export default function App() {
  const [user, setUser] = useState(null); const [checking, setChecking] = useState(true); const [notice, setNotice] = useState('');
  const [config, setConfig] = useState({ school: 'Student Performance Analyzer', allowRegister: false, devHint: false });
  const refreshUser = useCallback(() => api('/api/auth/me').then(r => setUser(r.user)).catch(() => {}), []);
  useEffect(() => {
    api('/api/config').then(setConfig).catch(() => {});
    (getToken() ? api('/api/auth/me').then(r => setUser(r.user)).catch(() => {}) : Promise.resolve()).finally(() => setChecking(false));
    const out = () => { setUser(null); setNotice('Your session has expired. Please log in again.'); };
    window.addEventListener('spa-logout', out); return () => window.removeEventListener('spa-logout', out);
  }, []);
  useEffect(() => { document.title = config.school + ' · Student Performance Analyzer'; }, [config]);
  if (checking) return <div className="login"><p>Loading…</p></div>;
  return <Boundary>{user
    ? <Shell user={user} config={config} refreshUser={refreshUser} logout={() => { setToken(null); setUser(null); setNotice(''); }} />
    : <Auth onAuth={u => { setNotice(''); setUser(u); }} notice={notice} config={config} />}<Toast /></Boundary>;
}

# Student Performance Analyzer

A small school SaaS: teachers log in, see how every section is doing, click a student to see their progress, and get gentle pointers on who might need support.

**Stack:** React (Vite) UI · Node.js + Express API · SQLite database · CSV import/export · JWT login with admin/teacher roles.

## What it does
* **Dashboard**: friendly summary, section trends, students who may need a conversation (low average, falling marks, low attendance), most improved, top performers
* **Students Information → Section → student row**: marks table; click a row for the progress charts; add/edit students and marks
* **Analytics** (SQL aggregates) and **EDA** (summary stats, histogram, correlation heatmap, attendance vs score)
* **Data (CSV)**: export `students.csv` / `marks.csv`, or import them (admin)
* **Team** (admin): invite teachers, change roles, remove people · **My account**: change password

## Run locally
```bash
npm install
npm start          # http://localhost:3000
```
Local demo login: `admin@school.com` / `admin123` (a banner will ask you to change it).
The first start creates `data/app.db` and loads 45 demo students from `data/*.csv`.

Development with hot reload: `npm run dev:server` and `npm run dev:client` (UI on :5173). Tests: `npm test`.

## Deploy
You need any host that runs a Node or Docker app **and keeps a persistent disk** (the SQL database is a file).

### Option A: Docker (any VPS)
```bash
cp .env.example .env      # edit it
docker compose up -d --build
```
Put it behind HTTPS (Caddy, nginx or your host's proxy). Data lives in the `spa-data` volume.

### Option B: Render
Push this folder to GitHub → Render → **New → Blueprint** → select the repo. `render.yaml` sets up the Docker service, a 1 GB disk, health check and a generated `JWT_SECRET`. Enter `ADMIN_EMAIL` and `ADMIN_PASSWORD` when asked. (Disks require a paid instance.) Railway and Fly.io work the same way: Dockerfile + a volume mounted at `/var/data`.

### Going live checklist
1. Set `ADMIN_PASSWORD` and `JWT_SECRET` (if you don't, a random admin password is printed once in the logs).
2. Set `SEED_SAMPLE=false` to start with an empty school, then import your real CSVs.
3. Keep `ALLOW_REGISTER=false` and invite teachers from the **Team** page.
4. Serve over HTTPS.
5. Back up regularly: copy the database file, or download both CSVs from **Data (CSV)**.

## Configuration
| Variable | Default | Purpose |
|---|---|---|
| `SCHOOL_NAME` | Greenfield Public School | Shown on login and navbar |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | admin@school.com / (dev: admin123, prod: random) | First admin account |
| `JWT_SECRET` | generated in data dir | Signs login tokens |
| `ALLOW_REGISTER` | true in dev, false in production | Public sign-up |
| `SEED_SAMPLE` | true | Load demo students on an empty database |
| `DATA_DIR` / `DB_FILE` / `PORT` | data / data/app.db / 3000 | Storage and port |

## CSV format
`students.csv`: `roll,name,section,attendance`
`marks.csv`: `roll,subject,exam,score`: subjects Math, Science, English, History, Computer; exams Unit 1, Midterm, Unit 2, Final. Every student needs all 20 marks. Bad files are rejected with a clear message and nothing is changed. Subjects and exams are defined in `server/config.js` and `client/src/api.js`.

## Good to know
* SQLite suits one school and one server instance. For many schools or several servers, move to PostgreSQL.
* Logins last 8 hours; login/sign-up attempts are rate limited; passwords are hashed with bcrypt; security headers via helmet.
* This is a learning and small-school tool. Review privacy rules (student data) that apply to your institution before storing real records.

## API
`GET /healthz` · `GET /api/config` · `POST /api/auth/login|register|password` · `GET /api/auth/me` · `GET|POST /api/students` · `GET|PUT|DELETE /api/students/:id` · `GET /api/analytics` · `GET /api/eda` · `GET /api/export/students|marks` · `POST /api/import` · `GET|POST /api/users`, `PATCH|DELETE /api/users/:id` (admin)

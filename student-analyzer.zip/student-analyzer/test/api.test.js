import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

// Isolated database + settings for the test run (must be set before the app is imported)
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'spa-test-'));
Object.assign(process.env, { NODE_ENV: 'test', DATA_DIR: dir, JWT_SECRET: 'test-secret', ADMIN_PASSWORD: 'Admin#12345', ALLOW_REGISTER: 'false' });

let server, base, admin, teacher;
const call = async (url, { method = 'GET', body, token } = {}) => {
  const res = await fetch(base + url, { method, headers: { ...(body ? { 'content-type': 'application/json' } : {}), ...(token ? { authorization: 'Bearer ' + token } : {}) }, body: body && JSON.stringify(body) });
  const ct = res.headers.get('content-type') || '';
  return { status: res.status, data: ct.includes('json') ? await res.json() : await res.text() };
};
const marks = v => [0, 1, 2, 3, 4].map(() => [v, v, v, v]);

before(async () => {
  const { app } = await import('../server/app.js');
  server = app.listen(0); base = `http://localhost:${server.address().port}`;
  admin = (await call('/api/auth/login', { method: 'POST', body: { email: 'admin@school.com', password: 'Admin#12345' } })).data.token;
});
after(() => { server.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('health check and public config work without login', async () => {
  assert.equal((await call('/healthz')).data.ok, true);
  assert.equal((await call('/api/config')).data.allowRegister, false);
});
test('data endpoints require login', async () => {
  assert.equal((await call('/api/students')).status, 401);
});
test('wrong password is rejected, right one works', async () => {
  assert.equal((await call('/api/auth/login', { method: 'POST', body: { email: 'admin@school.com', password: 'nope' } })).status, 401);
  assert.ok(admin);
});
test('sample CSV data was loaded into SQL on first start', async () => {
  const r = await call('/api/students', { token: admin });
  assert.equal(r.data.length, 45);
  assert.equal(r.data[0].marks.length, 5);
  assert.equal(r.data[0].marks[0].length, 4);
});
test('admin creates a teacher; sign-up is closed to the public', async () => {
  assert.equal((await call('/api/auth/register', { method: 'POST', body: { name: 'X', email: 'x@y.com', password: 'longpassword' } })).status, 403);
  const c = await call('/api/users', { method: 'POST', token: admin, body: { name: 'Ms Rao', email: 'rao@school.com', password: 'teachpass1', role: 'teacher' } });
  assert.equal(c.status, 201);
  teacher = (await call('/api/auth/login', { method: 'POST', body: { email: 'rao@school.com', password: 'teachpass1' } })).data.token;
  assert.ok(teacher);
});
test('teacher can add and edit a student but not delete or import', async () => {
  const c = await call('/api/students', { method: 'POST', token: teacher, body: { name: 'Test Kid', roll: 5555, section: 'd', attendance: 90, marks: marks(70) } });
  assert.equal(c.status, 201); assert.equal(c.data.section, 'D');
  const u = await call(`/api/students/${c.data.id}`, { method: 'PUT', token: teacher, body: { ...c.data, name: 'Test Kid Jr', marks: marks(80) } });
  assert.equal(u.data.marks[2][3], 80);
  assert.equal((await call(`/api/students/${c.data.id}`, { method: 'DELETE', token: teacher })).status, 403);
  assert.equal((await call('/api/import', { method: 'POST', token: teacher, body: { students: 'a', marks: 'b' } })).status, 403);
  assert.equal((await call(`/api/students/${c.data.id}`, { method: 'DELETE', token: admin })).status, 200);
});
test('validation: duplicate roll and bad body give friendly errors', async () => {
  const dup = await call('/api/students', { method: 'POST', token: admin, body: { name: 'Dup', roll: 1001, section: 'A', attendance: 80, marks: marks(60) } });
  assert.equal(dup.status, 409);
  assert.match((await call('/api/students', { method: 'POST', token: admin, body: { roll: 5 } })).data.error, /Name/);
});
test('analytics and EDA are computed from SQL', async () => {
  const a = (await call('/api/analytics', { token: admin })).data;
  assert.equal(a.kpis.total, 45); assert.ok(a.sections.length >= 3); assert.ok(a.attention.length > 0);
  const e = (await call('/api/eda', { token: admin })).data;
  assert.equal(e.ready, true); assert.equal(e.correlation.matrix.length, 6);
});
test('CSV export then re-import round-trips', async () => {
  const s = (await call('/api/export/students', { token: admin })).data, m = (await call('/api/export/marks', { token: admin })).data;
  assert.match(s, /^roll,name,section,attendance/);
  const r = await call('/api/import', { method: 'POST', token: admin, body: { students: s, marks: m, replace: true } });
  assert.equal(r.data.imported, 45);
});
test('import rejects incomplete marks and rolls back', async () => {
  const r = await call('/api/import', { method: 'POST', token: admin, body: { students: 'roll,name,section,attendance\n1,A,A,90', marks: 'roll,subject,exam,score\n1,Math,Unit 1,50', replace: true } });
  assert.equal(r.status, 400);
  assert.equal((await call('/api/students', { token: admin })).data.length, 45);
});
test('password change works and clears the flag', async () => {
  assert.equal((await call('/api/auth/password', { method: 'POST', token: teacher, body: { current: 'wrong', next: 'newpassword1' } })).status, 400);
  assert.equal((await call('/api/auth/password', { method: 'POST', token: teacher, body: { current: 'teachpass1', next: 'newpassword1' } })).status, 200);
  assert.ok((await call('/api/auth/login', { method: 'POST', body: { email: 'rao@school.com', password: 'newpassword1' } })).data.token);
});

import express from 'express';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db, allStudents, getStudent, createStudent, updateStudent, deleteStudent, importCsv, exportCsv } from './db.js';
import { analytics, eda } from './analytics.js';
import { SUBJECTS, EXAMS, DATA_DIR, PROD, SCHOOL_NAME, ALLOW_REGISTER } from './config.js';

// JWT secret: env var, or generated once and kept in the data directory
const SECRET = process.env.JWT_SECRET || (() => {
  const f = path.join(DATA_DIR, '.secret');
  if (!fs.existsSync(f)) fs.writeFileSync(f, crypto.randomBytes(48).toString('hex'), { mode: 0o600 });
  return fs.readFileSync(f, 'utf8');
})();

export const app = express();
if (PROD) app.set('trust proxy', 1);                       // behind Render/Railway/nginx
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"], imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], upgradeInsecureRequests: null } } }));
app.use(express.json({ limit: '5mb' }));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: process.env.NODE_ENV === 'test' ? 1000 : 25, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many attempts. Please wait a few minutes and try again.' } });
const sign = u => jwt.sign({ id: u.id, role: u.role }, SECRET, { expiresIn: '8h' });
const publicUser = u => ({ id: u.id, email: u.email, name: u.name, role: u.role, mustChange: !!u.must_change });
const fail = (status, error) => Object.assign(new Error(error), { status });
const wrap = fn => (req, res) => {
  try { fn(req, res); } catch (e) {
    const dup = e.code === 'SQLITE_CONSTRAINT_UNIQUE';
    res.status(e.status || (dup ? 409 : 400)).json({ error: dup ? 'That roll number or email is already in use' : e.message });
  }
};
function auth(req, res, next) {
  try {
    const p = jwt.verify((req.headers.authorization || '').replace(/^Bearer /, ''), SECRET);
    const u = db.prepare('SELECT * FROM users WHERE id = ?').get(p.id);
    if (!u) throw new Error('no user');
    req.user = u; next();
  } catch { res.status(401).json({ error: 'Please log in' }); }
}
const adminOnly = (req, res, next) => (req.user.role === 'admin' ? next() : res.status(403).json({ error: 'Only admins can do that' }));

/* ---------- public ---------- */
app.get('/healthz', (req, res) => { db.prepare('SELECT 1').get(); res.json({ ok: true }); });
app.get('/api/config', (req, res) => res.json({ school: SCHOOL_NAME, allowRegister: ALLOW_REGISTER, devHint: !PROD }));

app.post('/api/auth/login', authLimiter, wrap((req, res) => {
  const { email = '', password = '' } = req.body;
  const u = db.prepare('SELECT * FROM users WHERE email = ?').get(String(email).trim().toLowerCase());
  if (!u || !bcrypt.compareSync(String(password), u.password_hash)) throw fail(401, 'That email and password do not match. Please try again.');
  res.json({ token: sign(u), user: publicUser(u) });
}));
app.post('/api/auth/register', authLimiter, wrap((req, res) => {
  if (!ALLOW_REGISTER) throw fail(403, 'Sign-ups are closed. Please ask your school administrator for an account.');
  const { name = '', email = '', password = '' } = req.body;
  const id = addUser(name, email, password, 'teacher');
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  res.status(201).json({ token: sign(u), user: publicUser(u) });
}));
function addUser(name, email, password, role) {
  if (!String(name).trim()) throw new Error('Please enter a name');
  if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error('Please enter a valid email address');
  if (String(password).length < 8) throw new Error('Password must be at least 8 characters');
  return db.prepare('INSERT INTO users (email,name,password_hash,role) VALUES (?,?,?,?)')
    .run(email.trim().toLowerCase(), String(name).trim(), bcrypt.hashSync(password, 10), role).lastInsertRowid;
}

/* ---------- everything below needs login ---------- */
app.use('/api', auth);
app.get('/api/auth/me', (req, res) => res.json({ user: publicUser(req.user) }));
app.post('/api/auth/password', wrap((req, res) => {
  const { current = '', next = '' } = req.body;
  if (!bcrypt.compareSync(String(current), req.user.password_hash)) throw fail(400, 'Your current password is not correct');
  if (String(next).length < 8) throw new Error('New password must be at least 8 characters');
  db.prepare('UPDATE users SET password_hash = ?, must_change = 0 WHERE id = ?').run(bcrypt.hashSync(next, 10), req.user.id);
  res.json({ ok: true });
}));

app.get('/api/users', adminOnly, (req, res) => res.json(db.prepare('SELECT id,email,name,role,created_at FROM users ORDER BY id').all()));
app.post('/api/users', adminOnly, wrap((req, res) => {
  const { name, email, password, role = 'teacher' } = req.body;
  if (!['admin', 'teacher'].includes(role)) throw new Error('Invalid role');
  const id = addUser(name, email || '', password || '', role);
  res.status(201).json(db.prepare('SELECT id,email,name,role,created_at FROM users WHERE id = ?').get(id));
}));
app.patch('/api/users/:id', adminOnly, wrap((req, res) => {
  const id = Number(req.params.id), { role } = req.body;
  if (!['admin', 'teacher'].includes(role)) throw new Error('Invalid role');
  if (id === req.user.id) throw fail(400, 'You cannot change your own role');
  if (!db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, id).changes) throw fail(404, 'User not found');
  res.json({ ok: true });
}));
app.delete('/api/users/:id', adminOnly, wrap((req, res) => {
  const id = Number(req.params.id);
  if (id === req.user.id) throw fail(400, 'You cannot remove your own account');
  if (!db.prepare('DELETE FROM users WHERE id = ?').run(id).changes) throw fail(404, 'User not found');
  res.json({ ok: true });
}));

app.get('/api/meta', (req, res) => res.json({ subjects: SUBJECTS, exams: EXAMS }));
app.get('/api/students', (req, res) => res.json(allStudents(req.query.section)));
app.get('/api/students/:id', wrap((req, res) => { const s = getStudent(req.params.id); if (!s) throw fail(404, 'Student not found'); res.json(s); }));
app.post('/api/students', wrap((req, res) => res.status(201).json(createStudent(req.body))));
app.put('/api/students/:id', wrap((req, res) => { const s = updateStudent(Number(req.params.id), req.body); if (!s) throw fail(404, 'Student not found'); res.json(s); }));
app.delete('/api/students/:id', adminOnly, wrap((req, res) => { if (!deleteStudent(Number(req.params.id))) throw fail(404, 'Student not found'); res.json({ ok: true }); }));

app.get('/api/analytics', wrap((req, res) => res.json(analytics())));
app.get('/api/eda', wrap((req, res) => res.json(eda())));

app.get('/api/export/:type', wrap((req, res) => {
  if (!['students', 'marks'].includes(req.params.type)) throw fail(404, 'Unknown export');
  res.type('text/csv').attachment(`${req.params.type}.csv`).send(exportCsv(req.params.type));
}));
app.post('/api/import', adminOnly, wrap((req, res) => {
  const { students, marks, replace } = req.body;
  if (!students || !marks) throw new Error('Please choose both students.csv and marks.csv');
  res.json({ imported: importCsv(students, marks, !!replace) });
}));
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

/* ---------- React build ---------- */
const dist = path.join(path.dirname(fileURLToPath(import.meta.url)), '../client/dist');
if (fs.existsSync(dist)) {
  app.use('/assets', express.static(path.join(dist, 'assets'), { maxAge: '1y', immutable: true }));
  app.use(express.static(dist));
  app.use((req, res, next) => (req.method === 'GET' ? res.sendFile(path.join(dist, 'index.html')) : next()));
}
app.use((err, req, res, next) => res.status(err.status || 500).json({ error: err.type === 'entity.too.large' ? 'That file is too large' : 'Something went wrong on our side' }));

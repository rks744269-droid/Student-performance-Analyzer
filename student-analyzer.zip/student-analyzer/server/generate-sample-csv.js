// Generates realistic sample data -> data/students.csv and data/marks.csv.   Run: npm run seed
import fs from 'node:fs';
import { stringify } from 'csv-stringify/sync';
import { SUBJECTS, EXAMS } from './config.js';

function rng(s) { return () => { s |= 0; s = s + 0x6D2B79F5 | 0; let t = Math.imul(s ^ s >>> 15, 1 | s); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const r = rng(2026);
const gauss = (mu, sd) => mu + sd * Math.sqrt(-2 * Math.log(1 - r())) * Math.cos(2 * Math.PI * r());
const clamp = (v, lo = 20, hi = 100) => Math.max(lo, Math.min(hi, Math.round(v)));

const NAMES = ['Aarav Patel','Diya Sharma','Rohan Das','Ananya Roy','Kabir Singh','Meera Nair','Ishaan Gupta','Saanvi Rao','Vivaan Mehta','Priya Nayak',
  'Arjun Reddy','Tara Iyer','Neel Joshi','Riya Bose','Aditya Kumar','Kiara Menon','Dev Malhotra','Sneha Pillai','Yash Verma','Pooja Sethi',
  'Krish Jain','Navya Das','Om Prakash','Lavanya Rout','Harsh Vardhan','Ira Kapoor','Reyansh Shetty','Mahika Bhatt','Samar Qureshi','Anika Chopra',
  'Zayan Khan','Myra Fernandes','Atharv Kulkarni','Shreya Banerjee','Tanvi Deshmukh','Kunal Thakur','Aisha Siddiqui','Parth Agarwal','Nisha Mohanty','Rudra Behera',
  'Jiya Mishra','Vedant Naidu','Pranav Chaudhary','Sanya Mukherjee','Ayaan Dutta'];

const students = [['roll', 'name', 'section', 'attendance']];
const marks = [['roll', 'subject', 'exam', 'score']];
NAMES.forEach((name, i) => {
  const ability = gauss(66, 13);                                   // most students are average, a few excel or struggle
  const offsets = SUBJECTS.map(() => gauss(0, 8));                 // everyone has stronger and weaker subjects
  const mood = r();
  const trend = mood < .15 ? gauss(-5, 1.5) : mood > .8 ? gauss(5, 1.5) : gauss(0.8, 1.5);   // some slip, some surge
  const roll = 1001 + i;
  const attendance = clamp(62 + ability * .33 + gauss(0, 6), 45, 100);
  students.push([roll, name, 'ABC'[i % 3], attendance]);
  SUBJECTS.forEach((s, si) => EXAMS.forEach((e, ei) => marks.push([roll, s, e, clamp(ability + offsets[si] + trend * ei + gauss(0, 4))])));
});
fs.mkdirSync('data', { recursive: true });
fs.writeFileSync('data/students.csv', stringify(students));
fs.writeFileSync('data/marks.csv', stringify(marks));
console.log(`Wrote ${students.length - 1} students and ${marks.length - 1} marks to data/*.csv`);

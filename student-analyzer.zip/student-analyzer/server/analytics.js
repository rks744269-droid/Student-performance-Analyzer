import { db, allStudents } from './db.js';
import { SUBJECTS, EXAMS } from './config.js';

const FINAL = EXAMS[EXAMS.length - 1];
export const gradeOf = v => (v >= 85 ? 'A' : v >= 70 ? 'B' : v >= 55 ? 'C' : 'D');
const mean = a => a.reduce((x, y) => x + y, 0) / a.length;
const median = a => { const s = [...a].sort((x, y) => x - y), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
const std = a => { const m = mean(a); return Math.sqrt(mean(a.map(x => (x - m) ** 2))); };
const corr = (a, b) => {
  const ma = mean(a), mb = mean(b); let n = 0, da = 0, dbb = 0;
  a.forEach((x, i) => { n += (x - ma) * (b[i] - mb); da += (x - ma) ** 2; dbb += (b[i] - mb) ** 2; });
  const d = Math.sqrt(da * dbb);
  return d ? n / d : 0;
};

// Dashboard + analytics: computed with SQL aggregates
export function analytics() {
  const AVGS = `(SELECT student_id, AVG(score) a FROM marks WHERE exam = ? GROUP BY student_id)`;
  const kpi = db.prepare(`SELECT COUNT(*) total, AVG(a) avg, SUM(a < 55) atRisk FROM ${AVGS}`).get(FINAL);
  const attendance = db.prepare('SELECT AVG(attendance) v FROM students').get().v;
  const sections = db.prepare(`SELECT s.section, AVG(m.score) avg FROM marks m JOIN students s ON s.id = m.student_id WHERE m.exam = ? GROUP BY s.section ORDER BY s.section`).all(FINAL);
  const subjects = db.prepare('SELECT subject, AVG(score) avg FROM marks WHERE exam = ? GROUP BY subject').all(FINAL)
    .sort((a, b) => SUBJECTS.indexOf(a.subject) - SUBJECTS.indexOf(b.subject));
  const sectionTrend = {};
  for (const r of db.prepare(`SELECT s.section, m.exam, AVG(m.score) avg FROM marks m JOIN students s ON s.id = m.student_id GROUP BY s.section, m.exam`).all()) {
    (sectionTrend[r.section] ||= EXAMS.map(() => 0))[EXAMS.indexOf(r.exam)] = r.avg;
  }
  const subjectTrend = {};
  for (const r of db.prepare('SELECT subject, exam, AVG(score) avg FROM marks GROUP BY subject, exam').all()) {
    (subjectTrend[r.subject] ||= EXAMS.map(() => 0))[EXAMS.indexOf(r.exam)] = r.avg;
  }
  const grades = { A: 0, B: 0, C: 0, D: 0 };
  db.prepare(`SELECT a FROM ${AVGS}`).all(FINAL).forEach(r => grades[gradeOf(r.a)]++);
  const top = db.prepare(`SELECT s.id, s.name, s.section, t.a avg FROM ${AVGS} t JOIN students s ON s.id = t.student_id ORDER BY t.a DESC LIMIT 5`).all(FINAL);
  // Human-friendly follow-ups: who needs attention and who improved most
  const people = allStudents().map(st => {
    const first = mean(st.marks.map(m => m[0])), last = mean(st.marks.map(m => m[m.length - 1]));
    const weakest = SUBJECTS[st.marks.map(m => m[m.length - 1]).indexOf(Math.min(...st.marks.map(m => m[m.length - 1])))];
    const reasons = [];
    if (last < 55) reasons.push(`Average is ${last.toFixed(0)}, below 55`);
    if (last - first <= -5) reasons.push(`Down ${(first - last).toFixed(0)} points since Unit 1`);
    if (st.attendance < 75) reasons.push(`Attendance is only ${st.attendance}%`);
    if (reasons.length) reasons.push(`Weakest subject: ${weakest}`);
    return { id: st.id, name: st.name, section: st.section, avg: last, delta: last - first, reasons };
  });
  const attention = people.filter(p => p.reasons.length).sort((a, b) => b.reasons.length - a.reasons.length || a.avg - b.avg).slice(0, 6);
  const improved = people.filter(p => p.delta > 0).sort((a, b) => b.delta - a.delta).slice(0, 3).map(({ id, name, section, delta, avg }) => ({ id, name, section, delta, avg }));
  return {
    attention, improved,
    kpis: { total: kpi.total, avg: kpi.avg || 0, attendance: attendance || 0, atRisk: kpi.atRisk || 0 },
    sections, subjects, sectionTrend, subjectTrend, grades, top,
  };
}

// Exploratory data analysis
export function eda() {
  const st = allStudents().map(s => ({ ...s, final: s.marks.map(m => m[m.length - 1]) }));
  st.forEach(s => { s.avg = mean(s.final); });
  if (st.length < 3) return { ready: false, count: st.length };
  const cols = [
    ...SUBJECTS.map((n, i) => ({ name: n, values: st.map(s => s.final[i]) })),
    { name: 'Attendance', values: st.map(s => s.attendance) },
    { name: 'Average', values: st.map(s => s.avg) },
  ];
  const summary = cols.map(c => ({ name: c.name, mean: mean(c.values), median: median(c.values), std: std(c.values), min: Math.min(...c.values), max: Math.max(...c.values) }));
  const corrCols = cols.slice(0, SUBJECTS.length + 1);
  const correlation = { labels: corrCols.map(c => c.name), matrix: corrCols.map(a => corrCols.map(b => corr(a.values, b.values))) };
  const histogram = Array.from({ length: 6 }, (_, i) => ({ label: `${40 + i * 10}s`, value: st.filter(s => s.avg >= 40 + i * 10 && s.avg < 50 + i * 10 + (i === 5 ? 1 : 0)).length }));
  return {
    ready: true, count: st.length, summary, correlation, histogram,
    attendanceCorr: corr(cols[SUBJECTS.length].values, cols[SUBJECTS.length + 1].values),
    scatter: st.map(s => ({ name: s.name, att: s.attendance, avg: s.avg })),
  };
}

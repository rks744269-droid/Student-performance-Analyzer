import { app } from './app.js';
import { PORT, PROD } from './config.js';

const server = app.listen(PORT, () => console.log(`Student Performance Analyzer running on http://localhost:${PORT} (${PROD ? 'production' : 'development'})`));
const stop = () => server.close(() => process.exit(0));   // graceful shutdown for Docker/Render
process.on('SIGTERM', stop); process.on('SIGINT', stop);

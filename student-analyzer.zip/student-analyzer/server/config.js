import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const SUBJECTS = ['Math', 'Science', 'English', 'History', 'Computer'];
export const EXAMS = ['Unit 1', 'Midterm', 'Unit 2', 'Final'];

export const PROD = process.env.NODE_ENV === 'production';
export const PORT = process.env.PORT || 3000;
export const DATA_DIR = process.env.DATA_DIR || 'data';                 // where the database lives (mount a volume here)
export const DB_FILE = process.env.DB_FILE || path.join(DATA_DIR, 'app.db');
export const SEED_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), '../data'); // bundled sample CSVs
export const SCHOOL_NAME = process.env.SCHOOL_NAME || 'Greenfield Public School';
export const ALLOW_REGISTER = process.env.ALLOW_REGISTER ? process.env.ALLOW_REGISTER === 'true' : !PROD;
export const SEED_SAMPLE = process.env.SEED_SAMPLE !== 'false';
export const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'admin@school.com').toLowerCase();

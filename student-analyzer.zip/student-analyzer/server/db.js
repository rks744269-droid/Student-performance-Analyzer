import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { parse } from 'csv-parse/sync';
import { stringify } from 'csv-stringify/sync';
import path from 'node:path';
import { SUBJECTS, EXAMS, DATA_DIR, DB_FILE, SEED_DIR, SEED_SAMPLE, PROD, ADMIN_EMAIL } from './config.js';

fs.mkdirSync(DATA_DIR, { recursive: true });
export const db = new Database(DB_FILE);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'teacher' CHECK (role IN ('admin','teacher')),
  must_change INTEGER NOT NULL DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  roll INTEGER UNIQUE NOT NULL,
  name TEXT NOT NULL,
  section TEXT NOT NULL,
  attendance INTEGER NOT NULL CHECK (attendance BETWEEN 0 AND 100)
);
CREATE TABLE IF NOT EXISTS marks (
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject TEXT NOT NULL,
  exam TEXT NOT NULL,
  score INTEGER NOT NULL CHECK (score BETWEEN 0 AND 100),
  PRIMARY KEY (student_id, subject, exam)
);
CREATE INDEX IF NOT EXISTS idx_students_section ON students(section);
`);

/* ---------- students ---------- */
export function allStudents(section) {
  const rows = section
    ? db.prepare('SELECT * FROM students WHERE section = ? ORDER BY roll').all(section)
    : db.prepare('SELECT * FROM students ORDER BY roll').all();
  const marks = db.prepare('SELECT student_id, subject, exam, score FROM marks').all();
  const by = new Map(rows.map(s => [s.id, { ...s, marks: SUBJECTS.map(() => EXAMS.map(() => 0)) }]));
  for (const m of marks) {
    const s = by.get(m.student_id);
    if (s) s.marks[SUBJECTS.indexOf(m.subject)][EXAMS.indexOf(m.exam)] = m.score;
  }
  return [...by.values()];
}
export const getStudent = id => allStudents().find(s => s.id === Number(id));

const clampScore = v => Math.max(0, Math.min(100, Math.round(Number(v) || 0)));
export function validateStudent(b) {
  const name = String(b.name || '').trim();
  const roll = Number(b.roll);
  const section = String(b.section || '').trim().toUpperCase();
  if (!name) throw new Error('Name is required');
  if (!Number.isInteger(roll) || roll <= 0) throw new Error('Roll must be a positive whole number');
  if (!section) throw new Error('Section is required');
  if (!Array.isArray(b.marks) || b.marks.length !== SUBJECTS.length || b.marks.some(r => !Array.isArray(r) || r.length !== EXAMS.length))
    throw new Error(`Marks must be a ${SUBJECTS.length}x${EXAMS.length} matrix`);
  return { name, roll, section, attendance: clampScore(b.attendance), marks: b.marks.map(r => r.map(clampScore)) };
}
const writeMarks = (id, marks) => {
  const ins = db.prepare('INSERT OR REPLACE INTO marks (student_id, subject, exam, score) VALUES (?,?,?,?)');
  SUBJECTS.forEach((s, i) => EXAMS.forEach((e, j) => ins.run(id, s, e, marks[i][j])));
};
export const createStudent = db.transaction(b => {
  const v = validateStudent(b);
  const id = db.prepare('INSERT INTO students (roll,name,section,attendance) VALUES (?,?,?,?)').run(v.roll, v.name, v.section, v.attendance).lastInsertRowid;
  writeMarks(id, v.marks);
  return getStudent(id);
});
export const updateStudent = db.transaction((id, b) => {
  const v = validateStudent(b);
  const r = db.prepare('UPDATE students SET roll=?, name=?, section=?, attendance=? WHERE id=?').run(v.roll, v.name, v.section, v.attendance, id);
  if (!r.changes) return null;
  writeMarks(id, v.marks);
  return getStudent(id);
});
export const deleteStudent = id => db.prepare('DELETE FROM students WHERE id = ?').run(id).changes > 0;

/* ---------- CSV import / export ---------- */
const readCsv = text => parse(text, { columns: h => h.map(x => x.trim().toLowerCase()), skip_empty_lines: true, trim: true, bom: true });

export const importCsv = db.transaction((studentsText, marksText, replace) => {
  const sRows = readCsv(studentsText), mRows = readCsv(marksText);
  const need = (rows, cols, file) => { if (rows.length && cols.some(c => !(c in rows[0]))) throw new Error(`${file} must have columns: ${cols.join(', ')}`); };
  need(sRows, ['roll', 'name', 'section', 'attendance'], 'students.csv');
  need(mRows, ['roll', 'subject', 'exam', 'score'], 'marks.csv');
  const grid = new Map();
  for (const m of mRows) {
    const si = SUBJECTS.findIndex(s => s.toLowerCase() === m.subject.toLowerCase());
    const ei = EXAMS.findIndex(e => e.toLowerCase() === m.exam.toLowerCase());
    if (si < 0) throw new Error(`Unknown subject "${m.subject}". Allowed: ${SUBJECTS.join(', ')}`);
    if (ei < 0) throw new Error(`Unknown exam "${m.exam}". Allowed: ${EXAMS.join(', ')}`);
    const score = Number(m.score);
    if (!(score >= 0 && score <= 100)) throw new Error(`Invalid score "${m.score}" for roll ${m.roll}`);
    const g = grid.get(Number(m.roll)) || SUBJECTS.map(() => EXAMS.map(() => null));
    g[si][ei] = score; grid.set(Number(m.roll), g);
  }
  if (replace) db.exec('DELETE FROM marks; DELETE FROM students;');
  let count = 0;
  for (const s of sRows) {
    const roll = Number(s.roll), g = grid.get(roll);
    if (!g || g.some(r => r.some(x => x === null))) throw new Error(`Roll ${s.roll} (${s.name}) is missing marks. Every subject and exam is required.`);
    const v = validateStudent({ ...s, roll, marks: g });
    const ex = db.prepare('SELECT id FROM students WHERE roll = ?').get(roll);
    let id;
    if (ex) { id = ex.id; db.prepare('UPDATE students SET name=?, section=?, attendance=? WHERE id=?').run(v.name, v.section, v.attendance, id); }
    else id = db.prepare('INSERT INTO students (roll,name,section,attendance) VALUES (?,?,?,?)').run(v.roll, v.name, v.section, v.attendance).lastInsertRowid;
    writeMarks(id, v.marks); count++;
  }
  return count;
});

export function exportCsv(type) {
  if (type === 'students') {
    return stringify([['roll', 'name', 'section', 'attendance'], ...db.prepare('SELECT roll,name,section,attendance FROM students ORDER BY roll').all().map(Object.values)]);
  }
  const rows = db.prepare('SELECT s.roll, m.subject, m.exam, m.score FROM marks m JOIN students s ON s.id=m.student_id ORDER BY s.roll').all();
  rows.sort((a, b) => a.roll - b.roll || SUBJECTS.indexOf(a.subject) - SUBJECTS.indexOf(b.subject) || EXAMS.indexOf(a.exam) - EXAMS.indexOf(b.exam));
  return stringify([['roll', 'subject', 'exam', 'score'], ...rows.map(Object.values)]);
}

/* ---------- startup seeding ---------- */
if (!db.prepare('SELECT COUNT(*) c FROM users').get().c) {
  // Production: use ADMIN_PASSWORD, or generate a random one and print it once.
  let pw = process.env.ADMIN_PASSWORD, temp = false;
  if (!pw) { pw = PROD ? crypto.randomBytes(9).toString('base64url') : 'admin123'; temp = true; }
  db.prepare('INSERT INTO users (email,name,password_hash,role,must_change) VALUES (?,?,?,?,?)')
    .run(ADMIN_EMAIL, 'Administrator', bcrypt.hashSync(pw, 10), 'admin', temp ? 1 : 0);
  console.log(`Created admin account: ${ADMIN_EMAIL} / ${temp ? pw : '(from ADMIN_PASSWORD)'}${temp ? '   <- change it after first login' : ''}`);
}
const sCsv = path.join(SEED_DIR, 'students.csv'), mCsv = path.join(SEED_DIR, 'marks.csv');
if (SEED_SAMPLE && !db.prepare('SELECT COUNT(*) c FROM students').get().c && fs.existsSync(sCsv) && fs.existsSync(mCsv)) {
  const n = importCsv(fs.readFileSync(sCsv, 'utf8'), fs.readFileSync(mCsv, 'utf8'), false);
  console.log(`Loaded ${n} sample students from CSV (set SEED_SAMPLE=false to start empty)`);
}

# Customer Churn Prediction Project

End-to-end data science project predicting customer churn using the IBM Telco Customer Churn dataset.

## Project Structure

```
customer_churn_project/
├── data/
│   └── Telco-Customer-Churn.csv      # Raw dataset (7043 customers)
├── models/
│   └── best_churn_model.joblib       # Trained pipeline (ready for inference)
├── reports/
│   ├── 01_churn_distribution.png
│   ├── 02_numeric_by_churn.png
│   ├── 03_contract_vs_churn.png
│   ├── 04_correlation_heatmap.png
│   ├── 05_roc_curves.png
│   ├── 06_pr_curves.png
│   ├── 07_confusion_matrices.png
│   ├── 08_shap_summary.png
│   ├── 09_shap_importance.png
│   ├── model_comparison.csv
│   └── PROJECT_REPORT.md
├── src/
│   └── churn_analysis.py             # Full analysis pipeline
└── README.md
```

## Quick Start

### Run the full analysis
```bash
cd customer_churn_project
python src/churn_analysis.py
```

### Use the trained model for predictions
```python
import joblib
import pandas as pd

pipe = joblib.load("models/best_churn_model.joblib")

# new_customer_df must have the same columns as the training features
# (see src/churn_analysis.py for the exact feature list)
proba = pipe.predict_proba(new_customer_df)[:, 1]
print(f"Churn probability: {proba[0]:.1%}")
```

## Results Summary

| Model                | Test ROC-AUC | F1     | Precision | Recall |
|----------------------|--------------|--------|-----------|--------|
| **Logistic Regression** | **0.843**    | 0.626  | 0.519     | 0.786  |
| Random Forest        | 0.838        | 0.607  | 0.554     | 0.671  |
| XGBoost              | 0.837        | 0.621  | 0.504     | 0.808  |

**Best model:** Logistic Regression (highest ROC-AUC).

### Key Insights
- Month-to-month contracts → ~43% churn (vs ~3% for two-year)
- Fiber optic + no security/support → high risk
- Electronic check payment method → elevated churn
- New customers (low tenure) are most vulnerable

## Requirements
- Python 3.10+
- pandas, numpy, scikit-learn, matplotlib, seaborn
- xgboost, shap, imbalanced-learn, joblib, tabulate

```bash
pip install pandas numpy scikit-learn matplotlib seaborn xgboost shap imbalanced-learn joblib tabulate
```

## License
Dataset originally from IBM / Kaggle. Analysis code is free to use and adapt.

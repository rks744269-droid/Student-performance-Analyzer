#!/usr/bin/env python3
"""
Customer Churn Prediction - End-to-End Data Science Project
Telco Customer Churn Dataset

This script performs:
1. Data loading & cleaning
2. Exploratory Data Analysis (EDA)
3. Feature engineering
4. Model training & comparison (Logistic Regression, Random Forest, XGBoost)
5. Evaluation with business-relevant metrics
6. Model interpretability with SHAP
7. Saves plots, model, and a summary report
"""

import os
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_auc_score,
    roc_curve, precision_recall_curve, average_precision_score,
    f1_score, precision_score, recall_score
)
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline

import xgboost as xgb
import shap
import joblib

# -------------------------------------------------
# Paths
# -------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "data", "Telco-Customer-Churn.csv")
REPORTS_DIR = os.path.join(BASE_DIR, "reports")
MODELS_DIR = os.path.join(BASE_DIR, "models")
os.makedirs(REPORTS_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)

plt.style.use("seaborn-v0_8-whitegrid")
sns.set_palette("husl")

# -------------------------------------------------
# 1. Load & Clean
# -------------------------------------------------
print("=" * 60)
print("1. LOADING & CLEANING DATA")
print("=" * 60)

df = pd.read_csv(DATA_PATH)
print(f"Raw shape: {df.shape}")

# TotalCharges is object because of blank strings for new customers
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
print(f"Missing TotalCharges after conversion: {df['TotalCharges'].isna().sum()}")

# New customers with tenure=0 → TotalCharges = 0 is reasonable
df["TotalCharges"] = df["TotalCharges"].fillna(0)

# Target
df["Churn"] = (df["Churn"] == "Yes").astype(int)

# Drop customerID (not predictive)
df = df.drop(columns=["customerID"])

print(f"Cleaned shape: {df.shape}")
print(f"Churn rate: {df['Churn'].mean():.2%}")
print(f"Class balance:\n{df['Churn'].value_counts()}")

# -------------------------------------------------
# 2. Exploratory Data Analysis
# -------------------------------------------------
print("\n" + "=" * 60)
print("2. EXPLORATORY DATA ANALYSIS")
print("=" * 60)

# Basic stats
numeric_cols = ["tenure", "MonthlyCharges", "TotalCharges"]
print("\nNumeric features summary:")
print(df[numeric_cols].describe().round(2))

# Churn by key categoricals
cat_cols = [
    "gender", "SeniorCitizen", "Partner", "Dependents", "PhoneService",
    "MultipleLines", "InternetService", "OnlineSecurity", "OnlineBackup",
    "DeviceProtection", "TechSupport", "StreamingTV", "StreamingMovies",
    "Contract", "PaperlessBilling", "PaymentMethod"
]

# Plot 1: Churn distribution
fig, ax = plt.subplots(1, 2, figsize=(12, 4))
df["Churn"].value_counts().plot(kind="bar", ax=ax[0], color=["#2ecc71", "#e74c3c"])
ax[0].set_title("Churn Distribution (counts)")
ax[0].set_xticklabels(["No Churn", "Churn"], rotation=0)
ax[0].set_ylabel("Count")

df["Churn"].value_counts(normalize=True).plot(kind="bar", ax=ax[1], color=["#2ecc71", "#e74c3c"])
ax[1].set_title("Churn Distribution (proportion)")
ax[1].set_xticklabels(["No Churn", "Churn"], rotation=0)
ax[1].set_ylabel("Proportion")
plt.tight_layout()
plt.savefig(os.path.join(REPORTS_DIR, "01_churn_distribution.png"), dpi=150, bbox_inches="tight")
plt.close()
print("Saved: 01_churn_distribution.png")

# Plot 2: Tenure, MonthlyCharges, TotalCharges by Churn
fig, axes = plt.subplots(1, 3, figsize=(15, 4))
for i, col in enumerate(numeric_cols):
    sns.boxplot(data=df, x="Churn", y=col, ax=axes[i])
    axes[i].set_title(f"{col} by Churn")
    axes[i].set_xticklabels(["No", "Yes"])
plt.tight_layout()
plt.savefig(os.path.join(REPORTS_DIR, "02_numeric_by_churn.png"), dpi=150, bbox_inches="tight")
plt.close()
print("Saved: 02_numeric_by_churn.png")

# Plot 3: Contract type vs Churn (strongest categorical signal)
fig, ax = plt.subplots(figsize=(8, 5))
ct = pd.crosstab(df["Contract"], df["Churn"], normalize="index")
ct.plot(kind="bar", stacked=True, ax=ax, color=["#2ecc71", "#e74c3c"])
ax.set_title("Churn Rate by Contract Type")
ax.set_ylabel("Proportion")
ax.set_xlabel("Contract")
ax.legend(["No Churn", "Churn"], title="Churn")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(os.path.join(REPORTS_DIR, "03_contract_vs_churn.png"), dpi=150, bbox_inches="tight")
plt.close()
print("Saved: 03_contract_vs_churn.png")

# Plot 4: Correlation heatmap (numeric + binary)
df_corr = df.copy()
# Encode a few key binaries for correlation view
for col in ["Partner", "Dependents", "PhoneService", "PaperlessBilling"]:
    df_corr[col] = (df_corr[col] == "Yes").astype(int)
corr_cols = numeric_cols + ["SeniorCitizen", "Partner", "Dependents", "PhoneService", "PaperlessBilling", "Churn"]
corr = df_corr[corr_cols].corr()
fig, ax = plt.subplots(figsize=(9, 7))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="RdBu_r", center=0, ax=ax)
ax.set_title("Correlation Heatmap")
plt.tight_layout()
plt.savefig(os.path.join(REPORTS_DIR, "04_correlation_heatmap.png"), dpi=150, bbox_inches="tight")
plt.close()
print("Saved: 04_correlation_heatmap.png")

# Churn rates for all categoricals (text summary)
print("\nChurn rate by categorical feature:")
for col in cat_cols:
    rates = df.groupby(col)["Churn"].mean().sort_values(ascending=False)
    print(f"\n{col}:")
    print(rates.round(3).to_string())

# -------------------------------------------------
# 3. Feature Engineering & Preprocessing
# -------------------------------------------------
print("\n" + "=" * 60)
print("3. FEATURE ENGINEERING & PREPROCESSING")
print("=" * 60)

# Create a few useful features
df["TenureGroup"] = pd.cut(
    df["tenure"],
    bins=[-1, 12, 24, 48, 72],
    labels=["0-12", "13-24", "25-48", "49-72"]
)
df["AvgMonthlyCharge"] = df["TotalCharges"] / (df["tenure"] + 1)  # avoid div0
df["HasStreaming"] = ((df["StreamingTV"] == "Yes") | (df["StreamingMovies"] == "Yes")).astype(int)
df["HasSecurityBundle"] = (
    (df["OnlineSecurity"] == "Yes") &
    (df["OnlineBackup"] == "Yes") &
    (df["DeviceProtection"] == "Yes") &
    (df["TechSupport"] == "Yes")
).astype(int)

# Define feature sets
numeric_features = ["tenure", "MonthlyCharges", "TotalCharges", "AvgMonthlyCharge", "SeniorCitizen"]
categorical_features = [
    "gender", "Partner", "Dependents", "PhoneService", "MultipleLines",
    "InternetService", "OnlineSecurity", "OnlineBackup", "DeviceProtection",
    "TechSupport", "StreamingTV", "StreamingMovies", "Contract",
    "PaperlessBilling", "PaymentMethod", "TenureGroup"
]
# Binary engineered
binary_features = ["HasStreaming", "HasSecurityBundle"]

X = df[numeric_features + categorical_features + binary_features]
y = df["Churn"]

print(f"Features shape: {X.shape}")
print(f"Target shape: {y.shape}")

# Train / Test split (stratified)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
print(f"Train size: {X_train.shape[0]}, Test size: {X_test.shape[0]}")

# Preprocessor
preprocessor = ColumnTransformer(
    transformers=[
        ("num", StandardScaler(), numeric_features + binary_features),
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), categorical_features),
    ]
)

# -------------------------------------------------
# 4. Model Training
# -------------------------------------------------
print("\n" + "=" * 60)
print("4. MODEL TRAINING")
print("=" * 60)

models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42),
    "Random Forest": RandomForestClassifier(
        n_estimators=200, max_depth=10, class_weight="balanced",
        random_state=42, n_jobs=-1
    ),
    "XGBoost": xgb.XGBClassifier(
        n_estimators=200, max_depth=5, learning_rate=0.05,
        scale_pos_weight=(y_train == 0).sum() / (y_train == 1).sum(),
        random_state=42, eval_metric="logloss", n_jobs=-1
    ),
}

results = {}
trained_pipelines = {}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

for name, model in models.items():
    print(f"\nTraining {name}...")
    # Use imblearn pipeline for SMOTE only on train folds
    pipe = ImbPipeline(steps=[
        ("preprocessor", preprocessor),
        ("smote", SMOTE(random_state=42)),
        ("classifier", model),
    ])
    # Cross-val AUC
    cv_scores = cross_val_score(pipe, X_train, y_train, cv=cv, scoring="roc_auc", n_jobs=-1)
    print(f"  CV ROC-AUC: {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")

    # Fit on full train
    pipe.fit(X_train, y_train)
    trained_pipelines[name] = pipe

    # Predict on test
    y_pred = pipe.predict(X_test)
    y_proba = pipe.predict_proba(X_test)[:, 1]

    results[name] = {
        "y_pred": y_pred,
        "y_proba": y_proba,
        "roc_auc": roc_auc_score(y_test, y_proba),
        "avg_precision": average_precision_score(y_test, y_proba),
        "f1": f1_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "cv_auc_mean": cv_scores.mean(),
        "cv_auc_std": cv_scores.std(),
    }
    print(f"  Test ROC-AUC: {results[name]['roc_auc']:.4f}")
    print(f"  Test F1:      {results[name]['f1']:.4f}")
    print(f"  Test Precision: {results[name]['precision']:.4f}")
    print(f"  Test Recall:    {results[name]['recall']:.4f}")

# -------------------------------------------------
# 5. Evaluation Plots
# -------------------------------------------------
print("\n" + "=" * 60)
print("5. EVALUATION & VISUALIZATIONS")
print("=" * 60)

# ROC curves
fig, ax = plt.subplots(figsize=(8, 6))
for name, res in results.items():
    fpr, tpr, _ = roc_curve(y_test, res["y_proba"])
    ax.plot(fpr, tpr, label=f"{name} (AUC = {res['roc_auc']:.3f})")
ax.plot([0, 1], [0, 1], "k--", label="Random")
ax.set_xlabel("False Positive Rate")
ax.set_ylabel("True Positive Rate")
ax.set_title("ROC Curves – Test Set")
ax.legend(loc="lower right")
plt.tight_layout()
plt.savefig(os.path.join(REPORTS_DIR, "05_roc_curves.png"), dpi=150, bbox_inches="tight")
plt.close()
print("Saved: 05_roc_curves.png")

# Precision-Recall curves
fig, ax = plt.subplots(figsize=(8, 6))
for name, res in results.items():
    precision, recall, _ = precision_recall_curve(y_test, res["y_proba"])
    ax.plot(recall, precision, label=f"{name} (AP = {res['avg_precision']:.3f})")
ax.set_xlabel("Recall")
ax.set_ylabel("Precision")
ax.set_title("Precision-Recall Curves – Test Set")
ax.legend(loc="upper right")
plt.tight_layout()
plt.savefig(os.path.join(REPORTS_DIR, "06_pr_curves.png"), dpi=150, bbox_inches="tight")
plt.close()
print("Saved: 06_pr_curves.png")

# Confusion matrices
fig, axes = plt.subplots(1, 3, figsize=(15, 4))
for ax, (name, res) in zip(axes, results.items()):
    cm = confusion_matrix(y_test, res["y_pred"])
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
                xticklabels=["No Churn", "Churn"],
                yticklabels=["No Churn", "Churn"])
    ax.set_title(name)
    ax.set_ylabel("Actual")
    ax.set_xlabel("Predicted")
plt.tight_layout()
plt.savefig(os.path.join(REPORTS_DIR, "07_confusion_matrices.png"), dpi=150, bbox_inches="tight")
plt.close()
print("Saved: 07_confusion_matrices.png")

# Metrics comparison table
metrics_df = pd.DataFrame({
    name: {
        "CV ROC-AUC": f"{res['cv_auc_mean']:.4f} ± {res['cv_auc_std']:.4f}",
        "Test ROC-AUC": f"{res['roc_auc']:.4f}",
        "Avg Precision": f"{res['avg_precision']:.4f}",
        "F1": f"{res['f1']:.4f}",
        "Precision": f"{res['precision']:.4f}",
        "Recall": f"{res['recall']:.4f}",
    }
    for name, res in results.items()
}).T
print("\nModel Comparison:")
print(metrics_df.to_string())
metrics_df.to_csv(os.path.join(REPORTS_DIR, "model_comparison.csv"))
print("Saved: model_comparison.csv")

# -------------------------------------------------
# 6. Best Model + SHAP
# -------------------------------------------------
print("\n" + "=" * 60)
print("6. BEST MODEL & SHAP INTERPRETABILITY")
print("=" * 60)

# Choose best by Test ROC-AUC
best_name = max(results, key=lambda k: results[k]["roc_auc"])
best_pipe = trained_pipelines[best_name]
print(f"Best model by Test ROC-AUC: {best_name}")

# Save best model
model_path = os.path.join(MODELS_DIR, "best_churn_model.joblib")
joblib.dump(best_pipe, model_path)
print(f"Saved model → {model_path}")

# SHAP for the best model (sample for speed)
print("Computing SHAP values (this may take a minute)...")
# Transform data once
X_train_transformed = best_pipe.named_steps["preprocessor"].transform(X_train)
X_test_transformed = best_pipe.named_steps["preprocessor"].transform(X_test)

# Get feature names after one-hot
ohe = best_pipe.named_steps["preprocessor"].named_transformers_["cat"]
cat_feature_names = ohe.get_feature_names_out(categorical_features).tolist()
all_feature_names = numeric_features + binary_features + cat_feature_names

# SHAP TreeExplainer works well for RF / XGBoost; for LR use LinearExplainer
classifier = best_pipe.named_steps["classifier"]

# Use a sample of test set for SHAP
sample_idx = np.random.RandomState(42).choice(X_test_transformed.shape[0], size=min(300, X_test_transformed.shape[0]), replace=False)
X_shap = X_test_transformed[sample_idx]

if best_name == "Logistic Regression":
    explainer = shap.LinearExplainer(classifier, X_train_transformed)
    shap_values = explainer.shap_values(X_shap)
else:
    explainer = shap.TreeExplainer(classifier)
    shap_values = explainer.shap_values(X_shap)
    # For binary classification some versions return list
    if isinstance(shap_values, list):
        shap_values = shap_values[1]

# Summary plot
plt.figure(figsize=(10, 8))
shap.summary_plot(shap_values, X_shap, feature_names=all_feature_names, show=False, max_display=20)
plt.tight_layout()
plt.savefig(os.path.join(REPORTS_DIR, "08_shap_summary.png"), dpi=150, bbox_inches="tight")
plt.close()
print("Saved: 08_shap_summary.png")

# Bar plot of mean |SHAP|
plt.figure(figsize=(10, 8))
shap.summary_plot(shap_values, X_shap, feature_names=all_feature_names, plot_type="bar", show=False, max_display=15)
plt.tight_layout()
plt.savefig(os.path.join(REPORTS_DIR, "09_shap_importance.png"), dpi=150, bbox_inches="tight")
plt.close()
print("Saved: 09_shap_importance.png")

# -------------------------------------------------
# 7. Business Insights Report
# -------------------------------------------------
print("\n" + "=" * 60)
print("7. GENERATING SUMMARY REPORT")
print("=" * 60)

try:
    metrics_md = metrics_df.to_markdown()
except Exception:
    metrics_md = metrics_df.to_string()

report_lines = [
    "# Customer Churn Prediction – Project Report",
    "",
    "## Dataset",
    f"- Source: IBM Telco Customer Churn",
    f"- Rows: {df.shape[0]}, Features used: {X.shape[1]}",
    f"- Churn rate: {df['Churn'].mean():.1%}",
    "",
    "## Key Findings from EDA",
    "- Month-to-month contracts have dramatically higher churn than 1- or 2-year contracts.",
    "- Customers with fiber optic internet churn more than DSL or no internet.",
    "- Lack of online security / tech support is associated with higher churn.",
    "- Shorter tenure and higher monthly charges correlate with churn.",
    "- Electronic check payment method shows elevated churn.",
    "",
    "## Model Performance (Test Set)",
    metrics_md,
    "",
    f"**Best model:** {best_name} (highest Test ROC-AUC = {results[best_name]['roc_auc']:.4f})",
    "",
    "## Business Recommendations",
    "1. Target month-to-month customers with retention offers (discounts, free upgrades to annual plans).",
    "2. Promote security & support bundles – they appear protective against churn.",
    "3. Pay special attention to new customers (tenure < 12 months) and high monthly charge customers.",
    "4. Consider alternative payment methods or incentives for electronic-check users.",
    "5. Use the trained model to score the existing customer base monthly and prioritize outreach.",
    "",
    "## Files Produced",
    "- `reports/` – all plots and comparison table",
    "- `models/best_churn_model.joblib` – ready-to-use pipeline (preprocessor + SMOTE + classifier)",
    "",
    "## How to use the saved model",
    "```python",
    "import joblib",
    "pipe = joblib.load('models/best_churn_model.joblib')",
    "proba = pipe.predict_proba(new_customer_df)[:, 1]",
    "```",
    "",
    "---",
    "Generated by churn_analysis.py",
]

report_path = os.path.join(REPORTS_DIR, "PROJECT_REPORT.md")
with open(report_path, "w") as f:
    f.write("\n".join(report_lines))
print(f"Saved: {report_path}")

print("\n" + "=" * 60)
print("PROJECT COMPLETE")
print("=" * 60)
print(f"All outputs are in: {BASE_DIR}")
print(f"  - reports/  (plots + markdown report)")
print(f"  - models/   (trained pipeline)")
print(f"  - data/     (raw CSV)")
print(f"  - src/      (this script)")
